"""
tests/test_api.py — API integration tests using FastAPI TestClient.

Run with:
    pytest tests/ -v
"""

import io
import json
import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.database import SessionLocal, init_db, engine
from app import models

# ── Setup ─────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module", autouse=True)
def setup_db():
    """Ensure tables exist before tests run."""
    init_db()
    yield
    # Cleanup — drop all test records
    with SessionLocal() as db:
        db.query(models.Resume).delete()
        db.commit()


client = TestClient(app)


# ── Health check ──────────────────────────────────────────────────────────────

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data


def test_root():
    response = client.get("/")
    assert response.status_code == 200
    assert "service" in response.json()


# ── File type validation ───────────────────────────────────────────────────────

def test_upload_invalid_file_type():
    fake_file = io.BytesIO(b"not a real file")
    response  = client.post(
        "/resumes/upload",
        files={"file": ("resume.txt", fake_file, "text/plain")},
    )
    assert response.status_code == 400
    assert "Unsupported file type" in response.json()["detail"]


# ── Upload a minimal DOCX (python-docx created in-memory) ────────────────────

def _make_minimal_docx() -> bytes:
    from docx import Document
    doc  = Document()
    doc.add_heading("Jane Doe", level=1)
    doc.add_paragraph("Email: jane.doe@example.com")
    doc.add_paragraph("Phone: +91 98765 43210")
    doc.add_paragraph("Experience: 5 years in Data Science")
    doc.add_paragraph("Skills: Python, SQL, Machine Learning, TensorFlow")
    doc.add_heading("Work Experience", level=2)
    doc.add_paragraph("Senior Data Scientist | Acme Corp | 2021 - Present")
    doc.add_paragraph("Data Analyst | TechStart | 2019 - 2021")
    doc.add_heading("Education", level=2)
    doc.add_paragraph("B.Tech Computer Science | IIT Bombay | 2019")
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def test_upload_docx_fallback_mode(monkeypatch):
    """
    Tests the full upload pipeline with regex fallback
    (no Capgemini API key required for this test).
    """
    monkeypatch.setattr("app.routers.resumes.settings.CAPGEMINI_API_KEY", "")

    docx_bytes = _make_minimal_docx()
    response   = client.post(
        "/resumes/upload",
        files={"file": ("jane_doe.docx", io.BytesIO(docx_bytes), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["filename"] == "jane_doe.docx"
    assert data["parsing_status"] in ("processed", "failed")
    assert "metadata" in data


def test_list_resumes():
    response = client.get("/resumes/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_list_resumes_with_search():
    response = client.get("/resumes/?search=jane")
    assert response.status_code == 200


def test_get_nonexistent_resume():
    response = client.get("/resumes/999999")
    assert response.status_code == 404


def test_bulk_upload_invalid_files():
    files    = [
        ("files", ("bad.txt", io.BytesIO(b"bad"), "text/plain")),
        ("files", ("also_bad.csv", io.BytesIO(b"a,b,c"), "text/csv")),
    ]
    response = client.post("/resumes/bulk-upload", files=files)
    # Should still return 201 but with 0 successful
    assert response.status_code == 201
    data = response.json()
    assert data["failed"] == 2
    assert data["successful"] == 0
