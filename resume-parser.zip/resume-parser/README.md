# Resume Parser Microservice

AI-powered resume parsing microservice built with Python FastAPI + Capgemini LLM.
Extracts structured candidate metadata from PDF and DOCX resumes and stores
results in a SQL database. Designed to integrate with full-stack .NET applications
via REST API.

---

## Quick Start (VS Code)

### 1. Prerequisites
- Python 3.10+
- VS Code with Python extension installed
- Capgemini LLM API key and endpoint

### 2. Setup

```bash
# Clone / unzip the project, then:
cd resume-parser

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Mac/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env — add your CAPGEMINI_API_KEY and CAPGEMINI_API_URL
```

### 3. Run the server

```bash
uvicorn app.main:app --reload --port 8000
```

Open http://localhost:8000/docs to see the interactive Swagger UI.

### 4. Test the API

**Upload a single resume:**
```bash
curl -X POST "http://localhost:8000/resumes/upload" \
  -H "accept: application/json" \
  -F "file=@path/to/resume.pdf"
```

**List all parsed resumes:**
```bash
curl http://localhost:8000/resumes/
```

### 5. Run tests

```bash
pytest tests/ -v
```

---

## API Endpoints

| Method | Endpoint                    | Description                        |
|--------|-----------------------------|------------------------------------|
| POST   | /resumes/upload             | Upload + parse one resume          |
| POST   | /resumes/bulk-upload        | Upload + parse multiple resumes    |
| GET    | /resumes/                   | List all resumes (paginated)       |
| GET    | /resumes/{id}               | Get a specific resume by ID        |
| GET    | /resumes/{id}/raw-text      | Get extracted raw text             |
| DELETE | /resumes/{id}               | Soft-delete a resume               |
| GET    | /health                     | Health check                       |

---

## Database Configuration

**SQLite (default — zero setup):**
```
DATABASE_URL=sqlite:///./resume_parser.db
```

**SQL Server (production):**
```
DATABASE_URL=mssql+pyodbc://user:pass@server/db?driver=ODBC+Driver+17+for+SQL+Server
```
Also install: `pip install pyodbc`

---

## .NET Integration

See `dotnet_integration/` folder for:
- `ResumeParserClient.cs` — typed HTTP client (register in DI container)
- `ResumeController.cs`   — example controller wiring

Register in `Program.cs`:
```csharp
builder.Services.AddHttpClient<IResumeParserClient, ResumeParserClient>(client =>
{
    client.BaseAddress = new Uri("http://localhost:8000");
    client.Timeout = TimeSpan.FromSeconds(60);
});
```

---

## Project Structure

```
resume-parser/
├── app/
│   ├── main.py          ← FastAPI app + CORS + lifespan
│   ├── config.py        ← Settings (env vars)
│   ├── database.py      ← SQLAlchemy engine + session
│   ├── models.py        ← ORM table definition
│   ├── schemas.py       ← Pydantic request/response models
│   ├── extractor.py     ← PDF/DOCX → raw text
│   ├── parser.py        ← Capgemini LLM → structured JSON
│   └── routers/
│       └── resumes.py   ← All resume endpoints
├── dotnet_integration/
│   ├── ResumeParserClient.cs   ← .NET typed HTTP client
│   └── ResumeController.cs     ← Example .NET controller
├── tests/
│   └── test_api.py      ← pytest integration tests
├── .env.example
├── requirements.txt
└── README.md
```
