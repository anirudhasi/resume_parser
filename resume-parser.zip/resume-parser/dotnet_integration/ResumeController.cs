// ============================================================================
// ResumeController.cs  (example .NET controller wiring)
// Add this to your existing full-stack .NET application.
// ============================================================================

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using YourApp.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace YourApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ResumeController : ControllerBase
    {
        private readonly IResumeParserClient _parserClient;

        public ResumeController(IResumeParserClient parserClient)
        {
            _parserClient = parserClient;
        }

        /// <summary>
        /// Accepts a resume upload from the .NET UI and delegates parsing
        /// to the Python FastAPI microservice. The parsed metadata is returned
        /// to the frontend AND is also stored in the SQL DB by the microservice.
        /// </summary>
        [HttpPost("upload")]
        [RequestSizeLimit(10 * 1024 * 1024)]  // 10 MB
        public async Task<IActionResult> UploadResume(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No file provided.");

            var result = await _parserClient.ParseResumeAsync(file);

            if (result == null)
                return StatusCode(500, "Parsing service returned no result.");

            // Optionally: also persist to your .NET app's own DB here
            // await _yourDbContext.CandidateProfiles.AddAsync(MapToEntity(result));
            // await _yourDbContext.SaveChangesAsync();

            return Ok(result);
        }

        /// <summary>
        /// Bulk upload — for batch processing multiple resumes at once.
        /// </summary>
        [HttpPost("bulk-upload")]
        [RequestSizeLimit(100 * 1024 * 1024)]
        public async Task<IActionResult> BulkUpload(List<IFormFile> files)
        {
            if (files == null || files.Count == 0)
                return BadRequest("No files provided.");

            var result = await _parserClient.BulkParseResumesAsync(files);
            return Ok(result);
        }

        [HttpGet]
        public async Task<IActionResult> ListResumes(
            [FromQuery] int skip   = 0,
            [FromQuery] int limit  = 20,
            [FromQuery] string? search = null)
        {
            var resumes = await _parserClient.ListResumesAsync(skip, limit, search);
            return Ok(resumes);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetResume(int id)
        {
            var resume = await _parserClient.GetResumeAsync(id);
            if (resume == null) return NotFound();
            return Ok(resume);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> DeleteResume(int id)
        {
            var success = await _parserClient.DeleteResumeAsync(id);
            if (!success) return NotFound();
            return NoContent();
        }
    }
}
