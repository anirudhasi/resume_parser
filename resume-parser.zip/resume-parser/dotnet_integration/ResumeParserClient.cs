// ============================================================================
// ResumeParserClient.cs
// .NET Integration Client for the Resume Parser FastAPI Microservice
//
// Usage in Program.cs / Startup.cs:
//   builder.Services.AddHttpClient<IResumeParserClient, ResumeParserClient>(client =>
//   {
//       client.BaseAddress = new Uri("http://localhost:8000");
//       client.Timeout = TimeSpan.FromSeconds(60);
//   });
//
// Usage in a controller:
//   [HttpPost("upload")]
//   public async Task<IActionResult> UploadResume(IFormFile file)
//   {
//       var result = await _resumeParserClient.ParseResumeAsync(file);
//       return Ok(result);
//   }
// ============================================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace YourApp.Services
{
    // ── Response models (mirror Python schemas) ──────────────────────────────

    public class WorkExperience
    {
        [JsonPropertyName("company")]      public string? Company      { get; set; }
        [JsonPropertyName("role")]         public string? Role         { get; set; }
        [JsonPropertyName("start_date")]   public string? StartDate    { get; set; }
        [JsonPropertyName("end_date")]     public string? EndDate      { get; set; }
        [JsonPropertyName("duration")]     public string? Duration     { get; set; }
        [JsonPropertyName("years")]        public double? Years        { get; set; }
        [JsonPropertyName("location")]     public string? Location     { get; set; }
        [JsonPropertyName("responsibilities")] public List<string> Responsibilities { get; set; } = new();
    }

    public class Education
    {
        [JsonPropertyName("institution")] public string? Institution { get; set; }
        [JsonPropertyName("degree")]      public string? Degree      { get; set; }
        [JsonPropertyName("field")]       public string? Field       { get; set; }
        [JsonPropertyName("year")]        public string? Year        { get; set; }
        [JsonPropertyName("grade")]       public string? Grade       { get; set; }
    }

    public class Certification
    {
        [JsonPropertyName("name")]          public string? Name         { get; set; }
        [JsonPropertyName("issuer")]        public string? Issuer       { get; set; }
        [JsonPropertyName("year")]          public string? Year         { get; set; }
        [JsonPropertyName("credential_id")] public string? CredentialId { get; set; }
    }

    public class ResumeMetadata
    {
        [JsonPropertyName("candidate_name")]          public string?           CandidateName         { get; set; }
        [JsonPropertyName("email")]                   public string?           Email                 { get; set; }
        [JsonPropertyName("phone")]                   public string?           Phone                 { get; set; }
        [JsonPropertyName("age")]                     public int?              Age                   { get; set; }
        [JsonPropertyName("location")]                public string?           Location              { get; set; }
        [JsonPropertyName("linkedin_url")]            public string?           LinkedInUrl           { get; set; }
        [JsonPropertyName("total_experience_years")]  public double?           TotalExperienceYears  { get; set; }
        [JsonPropertyName("current_role")]            public string?           CurrentRole           { get; set; }
        [JsonPropertyName("current_company")]         public string?           CurrentCompany        { get; set; }
        [JsonPropertyName("professional_summary")]    public string?           ProfessionalSummary   { get; set; }
        [JsonPropertyName("skills")]                  public List<string>      Skills                { get; set; } = new();
        [JsonPropertyName("education")]               public List<Education>   EducationList         { get; set; } = new();
        [JsonPropertyName("work_history")]            public List<WorkExperience> WorkHistory        { get; set; } = new();
        [JsonPropertyName("certifications")]          public List<Certification>  Certifications     { get; set; } = new();
    }

    public class ParsedResumeResponse
    {
        [JsonPropertyName("id")]             public int            Id            { get; set; }
        [JsonPropertyName("filename")]       public string         Filename      { get; set; } = "";
        [JsonPropertyName("parsing_status")] public string         ParsingStatus { get; set; } = "";
        [JsonPropertyName("uploaded_at")]    public DateTime       UploadedAt    { get; set; }
        [JsonPropertyName("metadata")]       public ResumeMetadata Metadata      { get; set; } = new();
    }

    public class BulkParseResponse
    {
        [JsonPropertyName("total_files")]  public int                        TotalFiles  { get; set; }
        [JsonPropertyName("successful")]   public int                        Successful  { get; set; }
        [JsonPropertyName("failed")]       public int                        Failed      { get; set; }
        [JsonPropertyName("results")]      public List<ParsedResumeResponse> Results     { get; set; } = new();
    }

    // ── Interface ─────────────────────────────────────────────────────────────

    public interface IResumeParserClient
    {
        Task<ParsedResumeResponse?>        ParseResumeAsync(IFormFile file);
        Task<BulkParseResponse?>           BulkParseResumesAsync(IEnumerable<IFormFile> files);
        Task<ParsedResumeResponse?>        GetResumeAsync(int id);
        Task<List<ParsedResumeResponse>?>  ListResumesAsync(int skip = 0, int limit = 20, string? search = null);
        Task<bool>                         DeleteResumeAsync(int id);
    }

    // ── Implementation ────────────────────────────────────────────────────────

    public class ResumeParserClient : IResumeParserClient
    {
        private readonly HttpClient _httpClient;

        private static readonly JsonSerializerOptions _jsonOptions = new()
        {
            PropertyNameCaseInsensitive = true,
        };

        public ResumeParserClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        /// <summary>
        /// Upload a single resume file and return parsed metadata.
        /// </summary>
        public async Task<ParsedResumeResponse?> ParseResumeAsync(IFormFile file)
        {
            using var content    = new MultipartFormDataContent();
            using var fileStream = file.OpenReadStream();
            using var fileContent = new StreamContent(fileStream);

            fileContent.Headers.ContentType =
                new System.Net.Http.Headers.MediaTypeHeaderValue(file.ContentType ?? "application/octet-stream");

            content.Add(fileContent, "file", file.FileName);

            var response = await _httpClient.PostAsync("/resumes/upload", content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<ParsedResumeResponse>(_jsonOptions);
        }

        /// <summary>
        /// Upload multiple resume files in one call.
        /// </summary>
        public async Task<BulkParseResponse?> BulkParseResumesAsync(IEnumerable<IFormFile> files)
        {
            using var content = new MultipartFormDataContent();

            foreach (var file in files)
            {
                var fileStream  = file.OpenReadStream();
                var fileContent = new StreamContent(fileStream);
                fileContent.Headers.ContentType =
                    new System.Net.Http.Headers.MediaTypeHeaderValue(file.ContentType ?? "application/octet-stream");
                content.Add(fileContent, "files", file.FileName);
            }

            var response = await _httpClient.PostAsync("/resumes/bulk-upload", content);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<BulkParseResponse>(_jsonOptions);
        }

        /// <summary>
        /// Retrieve a parsed resume by its database ID.
        /// </summary>
        public async Task<ParsedResumeResponse?> GetResumeAsync(int id)
        {
            var response = await _httpClient.GetAsync($"/resumes/{id}");
            if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                return null;
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<ParsedResumeResponse>(_jsonOptions);
        }

        /// <summary>
        /// List all parsed resumes with optional search filter.
        /// </summary>
        public async Task<List<ParsedResumeResponse>?> ListResumesAsync(
            int skip = 0, int limit = 20, string? search = null)
        {
            var url      = $"/resumes/?skip={skip}&limit={limit}";
            if (!string.IsNullOrEmpty(search))
                url += $"&search={Uri.EscapeDataString(search)}";

            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();
            return await response.Content.ReadFromJsonAsync<List<ParsedResumeResponse>>(_jsonOptions);
        }

        /// <summary>
        /// Soft-delete a resume by ID. Returns true if successful.
        /// </summary>
        public async Task<bool> DeleteResumeAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"/resumes/{id}");
            return response.IsSuccessStatusCode;
        }
    }
}
