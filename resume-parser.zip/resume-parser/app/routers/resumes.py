"""
routers/resumes.py — All resume-related API endpoints.

Endpoints:
  POST   /resumes/upload          — Upload + parse a single resume
  POST   /resumes/bulk-upload     — Upload + parse multiple resumes
  GET    /resumes/                — List all resumes (paginated)
  GET    /resumes/{id}            — Get a specific resume by ID
  DELETE /resumes/{id}            — Soft-delete a resume
  GET    /resumes/{id}/raw-text   — Get the extracted raw text
"""

import json
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from sqlalchemy.orm import Session

from app import models, schemas
from app.config import settings
from app.database import get_db
from app.extractor import extract_text
from app.parser import parse_resume_with_llm, parse_resume_fallback

logger  = logging.getLogger(__name__)
router  = APIRouter(prefix="/resumes", tags=["Resumes"])

MAX_BYTES = settings.MAX_FILE_SIZE_MB * 1024 * 1024


# ── Helpers ───────────────────────────────────────────────────────────────────

def _validate_file(file: UploadFile):
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '.{ext}'. Allowed: {settings.ALLOWED_EXTENSIONS}",
        )


def _build_resume_response(db_resume: models.Resume) -> schemas.ResumeResponse:
    """Map ORM model → response schema, deserialising JSON string fields."""
    meta = schemas.ResumeMetadata(
        candidate_name         = db_resume.candidate_name,
        email                  = db_resume.email,
        phone                  = db_resume.phone,
        age                    = db_resume.age,
        location               = db_resume.location,
        linkedin_url           = db_resume.linkedin_url,
        total_experience_years = db_resume.total_experience_years,
        current_role           = db_resume.current_role,
        current_company        = db_resume.current_company,
        professional_summary   = db_resume.professional_summary,
        skills         = json.loads(db_resume.skills)         if db_resume.skills         else [],
        education      = json.loads(db_resume.education)      if db_resume.education      else [],
        work_history   = json.loads(db_resume.work_history)   if db_resume.work_history   else [],
        certifications = json.loads(db_resume.certifications) if db_resume.certifications else [],
    )
    return schemas.ResumeResponse(
        id             = db_resume.id,
        filename       = db_resume.filename,
        parsing_status = db_resume.parsing_status,
        uploaded_at    = db_resume.uploaded_at,
        metadata       = meta,
    )


def _process_single_file(file_bytes: bytes, filename: str, db: Session) -> models.Resume:
    """Core processing pipeline for one resume file."""
    db_resume = models.Resume(filename=filename, parsing_status="pending")
    db.add(db_resume)
    db.flush()  # get ID before committing

    try:
        # Step 1: Extract raw text
        raw_text, file_type = extract_text(file_bytes, filename)
        db_resume.raw_text  = raw_text
        db_resume.file_type = file_type

        # Step 2: Parse metadata via Capgemini LLM (fallback to regex if no API key)
        if settings.CAPGEMINI_API_KEY:
            metadata, parsed_json = parse_resume_with_llm(raw_text)
        else:
            logger.warning("No CAPGEMINI_API_KEY — using regex fallback.")
            metadata, parsed_json = parse_resume_fallback(raw_text)

        # Step 3: Persist structured fields
        db_resume.candidate_name         = metadata.candidate_name
        db_resume.email                  = metadata.email
        db_resume.phone                  = metadata.phone
        db_resume.age                    = metadata.age
        db_resume.location               = metadata.location
        db_resume.linkedin_url           = metadata.linkedin_url
        db_resume.total_experience_years = metadata.total_experience_years
        db_resume.current_role           = metadata.current_role
        db_resume.current_company        = metadata.current_company
        db_resume.professional_summary   = metadata.professional_summary
        db_resume.skills                 = json.dumps(metadata.skills         or [])
        db_resume.education              = json.dumps([e.dict() for e in (metadata.education      or [])])
        db_resume.work_history           = json.dumps([w.dict() for w in (metadata.work_history   or [])])
        db_resume.certifications         = json.dumps([c.dict() for c in (metadata.certifications or [])])
        db_resume.parsed_json            = parsed_json
        db_resume.parsing_status         = "processed"

    except Exception as e:
        logger.error(f"Processing failed for {filename}: {e}")
        db_resume.parsing_status = "failed"
        db_resume.error_message  = str(e)

    db.commit()
    db.refresh(db_resume)
    return db_resume


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/upload", response_model=schemas.ResumeResponse, status_code=status.HTTP_201_CREATED)
async def upload_resume(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Upload a single resume (PDF or DOCX) and extract metadata."""
    _validate_file(file)
    file_bytes = await file.read()
    if len(file_bytes) > MAX_BYTES:
        raise HTTPException(400, f"File exceeds {settings.MAX_FILE_SIZE_MB} MB limit.")

    db_resume = _process_single_file(file_bytes, file.filename, db)
    return _build_resume_response(db_resume)


@router.post("/bulk-upload", response_model=schemas.BulkUploadResponse, status_code=status.HTTP_201_CREATED)
async def bulk_upload_resumes(files: List[UploadFile] = File(...), db: Session = Depends(get_db)):
    """Upload and parse multiple resumes in one request."""
    results, successful, failed = [], 0, 0

    for file in files:
        try:
            _validate_file(file)
            file_bytes = await file.read()
            if len(file_bytes) > MAX_BYTES:
                raise ValueError(f"File size exceeds {settings.MAX_FILE_SIZE_MB} MB.")
            db_resume = _process_single_file(file_bytes, file.filename, db)
            results.append(_build_resume_response(db_resume))
            if db_resume.parsing_status == "processed":
                successful += 1
            else:
                failed += 1
        except Exception as e:
            failed += 1
            logger.error(f"Bulk upload error for {file.filename}: {e}")

    return schemas.BulkUploadResponse(
        total_files=len(files),
        successful=successful,
        failed=failed,
        results=results,
    )


@router.get("/", response_model=List[schemas.ResumeListItem])
def list_resumes(
    skip:   int            = Query(0, ge=0),
    limit:  int            = Query(20, ge=1, le=100),
    search: Optional[str]  = Query(None, description="Search by candidate name or email"),
    db:     Session        = Depends(get_db),
):
    """List all active resumes with optional name/email search."""
    query = db.query(models.Resume).filter(models.Resume.is_active == True)  # noqa: E712

    if search:
        pattern = f"%{search}%"
        query   = query.filter(
            (models.Resume.candidate_name.ilike(pattern)) |
            (models.Resume.email.ilike(pattern))
        )

    resumes = query.order_by(models.Resume.uploaded_at.desc()).offset(skip).limit(limit).all()
    return resumes


@router.get("/{resume_id}", response_model=schemas.ResumeResponse)
def get_resume(resume_id: int, db: Session = Depends(get_db)):
    """Retrieve full parsed metadata for a resume by ID."""
    db_resume = db.query(models.Resume).filter(
        models.Resume.id == resume_id,
        models.Resume.is_active == True,  # noqa: E712
    ).first()
    if not db_resume:
        raise HTTPException(status_code=404, detail=f"Resume {resume_id} not found.")
    return _build_resume_response(db_resume)


@router.get("/{resume_id}/raw-text")
def get_raw_text(resume_id: int, db: Session = Depends(get_db)):
    """Return the raw extracted text for debugging/audit purposes."""
    db_resume = db.query(models.Resume).filter(models.Resume.id == resume_id).first()
    if not db_resume:
        raise HTTPException(404, "Resume not found.")
    return {"id": resume_id, "filename": db_resume.filename, "raw_text": db_resume.raw_text}


@router.delete("/{resume_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_resume(resume_id: int, db: Session = Depends(get_db)):
    """Soft-delete a resume (sets is_active = False)."""
    db_resume = db.query(models.Resume).filter(models.Resume.id == resume_id).first()
    if not db_resume:
        raise HTTPException(404, "Resume not found.")
    db_resume.is_active = False
    db.commit()
