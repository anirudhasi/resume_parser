"""
extractor.py — Raw text extraction from PDF and DOCX files.

Strategy:
  PDF  → pdfplumber (best layout fidelity for resumes)
  DOCX → python-docx (preserves paragraph structure + tables)
"""

import io
import logging
from typing import Tuple

import pdfplumber
from docx import Document

logger = logging.getLogger(__name__)


def extract_text_from_pdf(file_bytes: bytes) -> str:
    """
    Extract text from a PDF using pdfplumber.
    Falls back page-by-page to maximise yield on tricky layouts.
    """
    text_parts = []
    try:
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            for page_num, page in enumerate(pdf.pages, start=1):
                try:
                    page_text = page.extract_text(x_tolerance=3, y_tolerance=3)
                    if page_text:
                        text_parts.append(page_text)
                    # Also extract any tables on the page
                    tables = page.extract_tables()
                    for table in tables:
                        for row in table:
                            cleaned = [cell.strip() if cell else "" for cell in row]
                            text_parts.append(" | ".join(cleaned))
                except Exception as e:
                    logger.warning(f"Page {page_num} extraction failed: {e}")
    except Exception as e:
        logger.error(f"PDF extraction error: {e}")
        raise ValueError(f"Cannot read PDF: {e}")

    full_text = "\n".join(text_parts).strip()
    if not full_text:
        raise ValueError("No text could be extracted from PDF. It may be scanned/image-based.")
    return full_text


def extract_text_from_docx(file_bytes: bytes) -> str:
    """
    Extract text from a DOCX file using python-docx.
    Includes paragraph text and table cells.
    """
    text_parts = []
    try:
        doc = Document(io.BytesIO(file_bytes))

        # Paragraphs
        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text.strip())

        # Tables
        for table in doc.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if cells:
                    text_parts.append(" | ".join(cells))

    except Exception as e:
        logger.error(f"DOCX extraction error: {e}")
        raise ValueError(f"Cannot read DOCX: {e}")

    full_text = "\n".join(text_parts).strip()
    if not full_text:
        raise ValueError("No text extracted from DOCX.")
    return full_text


def extract_text(file_bytes: bytes, filename: str) -> Tuple[str, str]:
    """
    Dispatch to the correct extractor based on file extension.

    Returns:
        (raw_text, file_type)  where file_type is 'pdf' or 'docx'
    """
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return extract_text_from_pdf(file_bytes), "pdf"
    elif lower.endswith(".docx") or lower.endswith(".doc"):
        return extract_text_from_docx(file_bytes), "docx"
    else:
        raise ValueError(f"Unsupported file type: {filename}. Use PDF or DOCX.")
