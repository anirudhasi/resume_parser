from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):
    # API
    APP_NAME: str = "Resume Parser API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    # Capgemini LLM configuration
    LLM_PROVIDER: str = "capgemini"
    CAPGEMINI_API_KEY: str = ""
    CAPGEMINI_API_URL: str = "https://api.capgemini.example.com/v1/llm"
    CAPGEMINI_MODEL: str = "capgemini-resume-parser-1"

    # Database — SQLite by default (swap for SQL Server below)
    # SQLite  : sqlite:///./resume_parser.db
    # SQL Server: mssql+pyodbc://user:pass@server/db?driver=ODBC+Driver+17+for+SQL+Server
    DATABASE_URL: str = "sqlite:///./resume_parser.db"

    # File upload limits
    MAX_FILE_SIZE_MB: int = 10
    ALLOWED_EXTENSIONS: list = ["pdf", "docx", "doc"]

    # CORS — add the .NET app origin here
    ALLOWED_ORIGINS: list = ["http://localhost:5000", "http://localhost:7000", "http://localhost:3000", "*"]

    class Config:
        env_file = ".env"


settings = Settings()
