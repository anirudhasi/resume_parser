"""
main.py — FastAPI application entry point for the Resume Parser microservice.

Start with:
    uvicorn app.main:app --reload --port 8000

Swagger UI: http://localhost:8000/docs
ReDoc:      http://localhost:8000/redoc
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import init_db
from app.routers import resumes

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG if settings.DEBUG else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Resume Parser API — initialising database …")
    init_db()
    logger.info("Database ready.")
    yield
    logger.info("Resume Parser API shutting down.")


# ── App factory ───────────────────────────────────────────────────────────────
app = FastAPI(
    title       = settings.APP_NAME,
    version     = settings.APP_VERSION,
    description = (
        "AI-powered resume parsing microservice. "
        "Extracts structured candidate metadata from PDF/DOCX resumes "
        "using Capgemini LLM and stores results in a SQL database. "
        "Designed to be consumed by any full-stack application via REST."
    ),
    lifespan    = lifespan,
)

# ── CORS — allow the .NET frontend origin ─────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins     = settings.ALLOWED_ORIGINS,
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(resumes.router)


# ── Health check ──────────────────────────────────────────────────────────────
@app.get("/health", tags=["System"])
def health_check():
    return JSONResponse({
        "status":  "ok",
        "version": settings.APP_VERSION,
        "db":      settings.DATABASE_URL.split("///")[0],  # driver only, no credentials
    })


@app.get("/", tags=["System"])
def root():
    return {
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs":    "/docs",
    }
