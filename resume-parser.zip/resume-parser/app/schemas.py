from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime


# ── Nested schemas ────────────────────────────────────────────────────────────

class WorkExperience(BaseModel):
    company:          Optional[str]        = None
    role:             Optional[str]        = None
    start_date:       Optional[str]        = None
    end_date:         Optional[str]        = None
    duration:         Optional[str]        = None
    years:            Optional[float]      = None
    responsibilities: Optional[List[str]]  = []
    location:         Optional[str]        = None


class Education(BaseModel):
    institution: Optional[str] = None
    degree:      Optional[str] = None
    field:       Optional[str] = None
    year:        Optional[str] = None
    grade:       Optional[str] = None


class Certification(BaseModel):
    name:         Optional[str] = None
    issuer:       Optional[str] = None
    year:         Optional[str] = None
    credential_id: Optional[str] = None


# ── Core metadata ─────────────────────────────────────────────────────────────

class ResumeMetadata(BaseModel):
    candidate_name:         Optional[str]                  = None
    email:                  Optional[str]                  = None
    phone:                  Optional[str]                  = None
    age:                    Optional[int]                  = None
    location:               Optional[str]                  = None
    linkedin_url:           Optional[str]                  = None
    total_experience_years: Optional[float]                = None
    current_role:           Optional[str]                  = None
    current_company:        Optional[str]                  = None
    skills:                 Optional[List[str]]            = []
    education:              Optional[List[Education]]      = []
    work_history:           Optional[List[WorkExperience]] = []
    certifications:         Optional[List[Certification]]  = []
    professional_summary:   Optional[str]                  = None


# ── API response schemas ───────────────────────────────────────────────────────

class ResumeResponse(BaseModel):
    id:             int
    filename:       str
    parsing_status: str
    uploaded_at:    datetime
    metadata:       ResumeMetadata

    class Config:
        from_attributes = True


class ResumeListItem(BaseModel):
    id:                     int
    filename:               str
    candidate_name:         Optional[str]
    email:                  Optional[str]
    current_role:           Optional[str]
    current_company:        Optional[str]
    total_experience_years: Optional[float]
    parsing_status:         str
    uploaded_at:            datetime

    class Config:
        from_attributes = True


class BulkUploadResponse(BaseModel):
    total_files:    int
    successful:     int
    failed:         int
    results:        List[ResumeResponse]


class HealthResponse(BaseModel):
    status:  str
    version: str
    db:      str
