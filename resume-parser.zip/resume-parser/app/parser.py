"""
parser.py — Structured metadata extraction using Capgemini LLM.

Capgemini's LLM receives the raw resume text and returns a strict JSON object
containing all candidate metadata. This approach handles ANY resume format/layout
with far superior accuracy compared to regex or NLP rules.
"""

import json
import logging
import re
from typing import Optional

import httpx

from app.config import settings
from app.schemas import ResumeMetadata

logger = logging.getLogger(__name__)

# ── Prompt engineering ─────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert HR data extraction engine.
Your ONLY job is to parse resume text and return a single, strictly valid JSON object.
Output ONLY the JSON — no markdown, no explanation, no preamble, no code fences.

Rules:
- Extract every field you can find; use null for missing fields.
- total_experience_years: compute from work history dates; if not computable set null.
- age: extract if explicitly stated; if only DOB is given compute from 2026; else null.
- skills: flat list of individual skill strings (tools, languages, frameworks, soft skills).
- education/work_history/certifications: arrays of objects as per schema.
- All string values must be clean — no leading/trailing whitespace.
- dates as strings e.g. "Jan 2020", "2018", "Present".

JSON schema to follow exactly:
{
  "candidate_name": "string|null",
  "email": "string|null",
  "phone": "string|null",
  "age": "integer|null",
  "location": "string|null",
  "linkedin_url": "string|null",
  "total_experience_years": "float|null",
  "current_role": "string|null",
  "current_company": "string|null",
  "professional_summary": "string|null",
  "skills": ["string"],
  "education": [
    {
      "institution": "string|null",
      "degree": "string|null",
      "field": "string|null",
      "year": "string|null",
      "grade": "string|null"
    }
  ],
  "work_history": [
    {
      "company": "string|null",
      "role": "string|null",
      "start_date": "string|null",
      "end_date": "string|null",
      "duration": "string|null",
      "years": "float|null",
      "location": "string|null",
      "responsibilities": ["string"]
    }
  ],
  "certifications": [
    {
      "name": "string|null",
      "issuer": "string|null",
      "year": "string|null",
      "credential_id": "string|null"
    }
  ]
}"""


def _clean_json_response(raw: str) -> str:
    """Strip accidental markdown fences from model output."""
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?", "", raw).strip()
    raw = re.sub(r"```$", "", raw).strip()
    return raw


def _extract_llm_text(payload: dict) -> Optional[str]:
    """Extract the most likely text output from a Capgemini LLM response."""
    if not isinstance(payload, dict):
        return None

    output = payload.get("output")
    if isinstance(output, dict):
        text = output.get("text")
        if isinstance(text, str) and text.strip():
            return text

    for candidate in (
        payload.get("response"),
        payload.get("text"),
    ):
        if isinstance(candidate, str) and candidate.strip():
            return candidate

    choices = payload.get("choices")
    if isinstance(choices, list) and choices:
        first = choices[0]
        if isinstance(first, dict):
            message = first.get("message")
            if isinstance(message, dict):
                candidate = message.get("content")
                if isinstance(candidate, str) and candidate.strip():
                    return candidate
            candidate = first.get("text")
            if isinstance(candidate, str) and candidate.strip():
                return candidate

    return None


def _call_capgemini_llm(raw_text: str) -> str:
    """Call the configured Capgemini LLM endpoint and return raw text output."""
    if not settings.CAPGEMINI_API_KEY:
        raise ValueError(
            "CAPGEMINI_API_KEY is not set. Add it to your .env file."
        )

    if not settings.CAPGEMINI_API_URL:
        raise ValueError(
            "CAPGEMINI_API_URL is not set. Add it to your .env file."
        )

    truncated_text = raw_text[:12000] if len(raw_text) > 12000 else raw_text
    prompt = f"{SYSTEM_PROMPT}\n\nParse this resume:\n\n{truncated_text}"

    payload = {
        "model": settings.CAPGEMINI_MODEL,
        "input": prompt,
        "max_tokens": 2048,
    }

    headers = {
        "Authorization": f"Bearer {settings.CAPGEMINI_API_KEY}",
        "Content-Type": "application/json",
    }

    try:
        response = httpx.post(settings.CAPGEMINI_API_URL, json=payload, headers=headers, timeout=60.0)
        response.raise_for_status()
        data = response.json()
    except httpx.HTTPStatusError as e:
        logger.error(f"Capgemini LLM HTTP error: {e}")
        raise ValueError(f"Capgemini LLM HTTP error: {e}") from e
    except httpx.RequestError as e:
        logger.error(f"Capgemini LLM request error: {e}")
        raise ValueError(f"Capgemini LLM request error: {e}") from e

    raw_json = _extract_llm_text(data)
    if not raw_json:
        logger.error(f"Capgemini LLM returned unexpected payload: {data}")
        raise ValueError("Capgemini LLM returned an unexpected response format.")

    return raw_json


def parse_resume_with_llm(raw_text: str) -> tuple[ResumeMetadata, str]:
    """
    Send resume text to Capgemini LLM and return a validated ResumeMetadata object.

    Raises:
        ValueError if API call fails or JSON is unparseable.
    """
    raw_json = _call_capgemini_llm(raw_text)
    cleaned = _clean_json_response(raw_json)

    try:
        parsed_dict = json.loads(cleaned)
        metadata = ResumeMetadata(**parsed_dict)
        return metadata, cleaned

    except json.JSONDecodeError as e:
        logger.error(f"JSON parse error from Capgemini response: {e}")
        raise ValueError(f"Capgemini LLM returned invalid JSON: {e}") from e


def parse_resume_fallback(raw_text: str) -> ResumeMetadata:
    """
    Basic regex fallback when Capgemini API key is not available.
    Extracts email, phone, and name heuristically.
    Not production-grade — use for local testing without API key.
    """
    import re

    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", raw_text)
    phone_match = re.search(r"[\+\(]?[0-9][0-9 .\-\(\)]{8,}[0-9]", raw_text)

    # First non-empty line is usually the name in most resume formats
    lines        = [l.strip() for l in raw_text.split("\n") if l.strip()]
    name_guess   = lines[0] if lines else None

    return ResumeMetadata(
        candidate_name=name_guess,
        email=email_match.group(0) if email_match else None,
        phone=phone_match.group(0) if phone_match else None,
    ), "{}"
