from sqlalchemy import Column, Integer, String, Float, DateTime, Text, Boolean
from sqlalchemy.sql import func
from app.database import Base


class Resume(Base):
    """
    Stores parsed resume metadata.
    All list fields (skills, education, work_history) are stored as JSON strings
    so they work across SQLite, SQL Server, PostgreSQL without schema changes.
    """
    __tablename__ = "resumes"

    id                     = Column(Integer, primary_key=True, index=True, autoincrement=True)
    filename               = Column(String(255), nullable=False)
    file_type              = Column(String(10))                     # pdf | docx

    # ── Core candidate info ──────────────────────────────────────────────────
    candidate_name         = Column(String(255))
    email                  = Column(String(255), index=True)
    phone                  = Column(String(50))
    age                    = Column(Integer,  nullable=True)
    location               = Column(String(255), nullable=True)
    linkedin_url           = Column(String(500), nullable=True)

    # ── Experience ───────────────────────────────────────────────────────────
    total_experience_years = Column(Float, nullable=True)
    current_role           = Column(String(255), nullable=True)
    current_company        = Column(String(255), nullable=True)

    # ── Structured lists stored as JSON strings ───────────────────────────────
    skills                 = Column(Text, nullable=True)   # JSON array
    education              = Column(Text, nullable=True)   # JSON array of objects
    work_history           = Column(Text, nullable=True)   # JSON array of objects
    certifications         = Column(Text, nullable=True)   # JSON array

    # ── Summary & raw content ─────────────────────────────────────────────────
    professional_summary   = Column(Text, nullable=True)
    raw_text               = Column(Text, nullable=True)
    parsed_json            = Column(Text, nullable=True)   # Full LLM output JSON

    # ── System fields ─────────────────────────────────────────────────────────
    uploaded_at            = Column(DateTime(timezone=True), server_default=func.now())
    updated_at             = Column(DateTime(timezone=True), onupdate=func.now())
    parsing_status         = Column(String(50), default="processed")   # processed | failed | pending
    error_message          = Column(Text, nullable=True)
    is_active              = Column(Boolean, default=True)
